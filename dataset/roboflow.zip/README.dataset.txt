# deathstar > 2025-01-16 9:08am
https://universe.roboflow.com/tp2-pe56o/deathstar-kebsz

Provided by a Roboflow user
License: CC BY 4.0

